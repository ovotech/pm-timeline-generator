import re
import time
from datetime import datetime
from functools import lru_cache
import html
import os

import slack


BOT_TOKEN = os.environ["BOT_TOKEN"]


def list_channels(client, cursor=''):
    resp = client.channels_list(cursor=cursor)
    yield from resp.data['channels']
    next_cursor = resp.data['response_metadata']['next_cursor']
    if next_cursor:
        yield from list_channels(client, cursor=next_cursor)


def get_channel_history(client, channel_id, latest=None):
    if latest is None:
        latest = str(time.mktime(datetime.now().timetuple()))
    resp = client.channels_history(channel=channel_id, latest=latest)
    messages = resp.data['messages']
    yield from messages
    if resp.data['has_more']:
        yield from get_channel_history(client,
                                       channel_id,
                                       latest=messages[-1]['ts'])


def get_reacted_messages(client, channel_id, reaction):
    reaction = reaction[1:-1]
    for message in get_channel_history(client, channel_id):
        if "reactions" in message:
            for r in message['reactions']:
                if r['name'] == reaction:
                    yield message


@lru_cache(maxsize=128)
def lookup_user(client, user_id):
    return client.users_info(user=user_id).data['user']


def who_posted_message(client, message):
    if 'user' in message:
        user = lookup_user(client, message['user'])
        return user['profile']['real_name']
    else:
        return message['username']
        # bot = lookup_bot(client, message['bot_id'])
        # return bot['bot']['name']


def format_slack_msg(client, text):
    users = {user_id: lookup_user(client, user_id)['profile']['real_name']
             for user_id in set(re.findall(r"<@([^>]+)>", text))}
    for user_id, name in users.items():
        text = text.replace(f"<@{user_id}>", "@"+name)

    text = html.unescape(text)
    return text.replace('\n\n', '\n')


def print_timestamped_message(client, messages):
    output = ""
    for message in messages:
        # print(message)
        user_name = who_posted_message(client, message)
        # print(user_name)
        timestamp = int(message['ts'].split(".")[0])
        # print(message)
        text = message['text']
        if 'attachments' in message:
            other_text = "\n".join(attachment['text'].strip()
                                   for attachment in message['attachments']
                                   if attachment['text'])
            if other_text:
                text = text + "\n" + other_text

        text = format_slack_msg(client, text)
        print(datetime.fromtimestamp(timestamp), user_name + ":", text)
        output += f'{datetime.fromtimestamp(timestamp)} {user_name} : {text}\n'

    return output


def get_im_channel(client, user_id):
    response = client.im_list(limit=200)
    im_channels = response['ims']

    while response['response_metadata']['next_cursor']:
        cursor = response['response_metadata']['next_cursor']
        response = client.im_list(limit=20, cursor=cursor)
        im_channels.extend(response['ims'])

    for user in im_channels:
        if user['user'] == 'U8WCEUH6Y':
            return user


def send_timeline_as_file(client, chan, output):
    return client.files_upload(channels=chan, content=output, title="Timeline")


def lambda_handler(event, context):
    print(f'event recieved: {event}')
    main(event)
    return None


def main(command_data):
    reaction = command_data.get('text', None)
    channel_id = command_data['channel_id'][0]
    user_id = command_data['user_id'][0]

    client = slack.WebClient(token=BOT_TOKEN)

    reacted = list(
        get_reacted_messages(client, channel_id, reaction[0])
    )[::-1]

    file_output = print_timestamped_message(client, reacted)

    user_im_channel = get_im_channel(client, user_id)

    send_timeline_as_file(client, user_im_channel, file_output)

    return None
